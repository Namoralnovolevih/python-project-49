### Hexlet tests and linter status:
[![Actions Status](https://github.com/Namoralnovolevih/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Namoralnovolevih/python-project-49/actions)

### Example installing a package, starting a game, winning and losing a player:
[![asciicast](https://asciinema.org/a/B05JIeeT4GUS6Trog2FVa0bvI.svg)](https://asciinema.org/a/B05JIeeT4GUS6Trog2FVa0bvI)
