### Hexlet tests and linter status:
[![Actions Status](https://github.com/Namoralnovolevih/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Namoralnovolevih/python-project-49/actions)

### brain-game:
[![asciicast](https://asciinema.org/a/B05JIeeT4GUS6Trog2FVa0bvI.svg)](https://asciinema.org/a/B05JIeeT4GUS6Trog2FVa0bvI)

### brain-cacl:
[![asciicast](https://asciinema.org/a/E3QhZ7RJn2aKgEtfBZRpSlSPl.svg)](https://asciinema.org/a/E3QhZ7RJn2aKgEtfBZRpSlSPl)

### brain-gcd:
[![asciicast](https://asciinema.org/a/F0kTA7kpv2saV5qZeCEYtyNok.svg)](https://asciinema.org/a/F0kTA7kpv2saV5qZeCEYtyNok)
