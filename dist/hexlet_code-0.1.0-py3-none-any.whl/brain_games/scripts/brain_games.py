#!/usr/bin/env python3
def main():
    return print("Welcome to the Brain Games!")

if __name__ == '__main__':
    main()

